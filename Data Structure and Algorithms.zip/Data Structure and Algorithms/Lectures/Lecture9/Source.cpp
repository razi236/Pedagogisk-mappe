#include "myLinkedList.h"

int main()
{
	myLinkedList obj;

	obj.insertSorted(15);
	obj.insertSorted(-3);
	obj.insertSorted(-6);
	obj.insertSorted(10);

	//insert sorted nullptr case is still left (last value to be inserted)


	return 0;
}