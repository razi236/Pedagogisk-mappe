#pragma once
struct Node
{
	int data;
	Node* next;
};