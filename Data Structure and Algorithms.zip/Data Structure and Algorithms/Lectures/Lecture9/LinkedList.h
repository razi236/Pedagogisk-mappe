#pragma once
#include "Node.h"

class LinkedList
{
protected:
	Node* head;
public:
	virtual void insertAtTail(int) = 0;
	virtual void insertSorted(int) = 0;
	LinkedList()
	{
		head = 0;
	}
};