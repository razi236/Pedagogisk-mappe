#pragma once
#include "LinkedList.h"

class myLinkedList:public LinkedList
{
public:
	void insertAtTail(int value);
	void insertSorted(int value);
};

void myLinkedList::insertSorted(int value)
{
	Node* nn;
	nn = new Node;
	nn->data = value;
	nn->next = nullptr;

	if (head == nullptr)
	{
		head = nn;
	}

	else
	{
		if (value <= head->data) //value to be inserted before head
		{
			nn->next = head;
			head = nn;
		}

		else
		{
			Node* t = head;

			while (1)
			{
				if (t->next->data >= value)
				{
					break;
				}

				t = t->next;
			}

			nn->next = t->next;
			t->next = nn;
		}
	}
}

void myLinkedList::insertAtTail(int value)
{
	Node* nn;
	nn = new Node;
	nn->data = value;
	nn->next = nullptr;

	if (head == nullptr)
	{
		head = nn;
	}

	else
	{
		Node* t = head;

		while (1)
		{
			if (t->next == nullptr)
				break;

			t = t->next;
		}

		t->next = nn;

	}
}