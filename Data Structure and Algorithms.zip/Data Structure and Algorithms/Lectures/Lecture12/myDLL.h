#pragma once
#include "LinkedList.h"

class myDLL :public LinkedList
{
public:
	void insertAtTail(int value);
	void insertAtHead(int value);
	void displayFromHead();
	void displayFromTail();

	bool deleteValue(int);
};

bool myDLL::deleteValue(int value)
{
	if (head == nullptr && tail == nullptr)
		return false;

	else if (value == head->data && head == tail) //single NODE case
	{
		delete head;
		head = nullptr;
		tail = nullptr;
		return true;
	}

	else if (value == head->data)
	{
		head = head->next;
		delete head->prev;
		head->prev = nullptr;
		return true;
	}

	else if (value == tail->data)
	{
		tail = tail->prev;
		delete tail->next;
		tail->next = nullptr;
		return true;
	}

	else
	{
		Node* t = head;

		while (1)
		{
			if (t->data == value)
				break;

			t = t->next;
		}

		t->prev->next = t->next;
		t->next->prev = t->prev;
		delete t;
		t = nullptr;
		return true;
	}
}

void myDLL::displayFromTail()
{
	if (head == nullptr && tail == nullptr)
		cout << "DLL is empty" << endl;

	else
	{
		Node* t = tail;

		while (1)
		{
			cout << t->data << endl;

			if (t->prev == nullptr)
				break;

			t = t->prev;

		}
	}
}

void myDLL::displayFromHead()
{
	if (head == nullptr && tail == nullptr)
		cout << "DLL is empty" << endl;

	else
	{
		Node* t = head;

		while (1)
		{
			cout << t->data << endl;
			
			if (t->next == nullptr)
				break;

			t = t->next;

		}
	}
}

void myDLL::insertAtTail(int value)
{
	Node* nn = new Node;
	nn->data = value;
	nn->next = nullptr;
	nn->prev = nullptr;

	if (head == nullptr && tail == nullptr)
	{
		head = nn;
		tail = nn;
	}

	else
	{
		nn->prev = tail;
		tail->next = nn;
		tail = nn;
	}
}

void myDLL::insertAtHead(int value)
{
	Node* nn = new Node;
	nn->data = value;
	nn->next = nullptr;
	nn->prev = nullptr;

	if (head == nullptr && tail == nullptr)
	{
		head = nn;
		tail = nn;
	}

	else
	{
		nn->next = head;
		head->prev = nn;
		head = head->prev; //head = nn;
	}
}
