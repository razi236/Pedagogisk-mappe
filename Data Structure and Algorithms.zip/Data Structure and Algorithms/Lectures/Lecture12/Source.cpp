#include "myDLL.h"

int main()
{
	myDLL dll;

	dll.insertAtTail(15);
	dll.insertAtTail(-3);
	dll.insertAtTail(99);
	dll.insertAtHead(55);

	dll.deleteValue(-3);

	dll.displayFromHead();
	
	return 0;
}