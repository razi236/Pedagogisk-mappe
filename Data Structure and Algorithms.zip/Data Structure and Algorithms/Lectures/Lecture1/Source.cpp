#include "myArray.h"

int main()
{
	myArray myObj;

	myObj.display();

	myObj.addValue(80);

	return 0;
}