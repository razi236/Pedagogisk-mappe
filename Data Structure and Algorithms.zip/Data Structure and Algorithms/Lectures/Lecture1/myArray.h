#pragma once
#include "Array.h"

class myArray :public Array
{
public:
	void addValue(int);	//function over-riding
	int removeValue();	//function over-riding
	void display();
};

void myArray::display()
{
	cout << "my own local function" << endl;
}


int myArray::removeValue()
{
	return 0;
}


void myArray::addValue(int value)
{
	cout << "Kuch Bhi naheen" << endl;
}