#include "BST.h"
using namespace std;

int main()
{
	BST bst1;
	
	bst1.insert(20);
	bst1.insert(10);
	bst1.insert(30);
	bst1.insert(5);
	bst1.insert(15);
	bst1.insert(3);
	bst1.insert(7);
	bst1.insert(6);
	bst1.insert(1);
	bst1.insert(25);
	bst1.insert(100);
	
	bst1.deleteValue(100);
	
	bst1.inorder();
	
	BST obj2;
	
	
	return 0;
}