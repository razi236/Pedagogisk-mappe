#include "myDCLL.h"

int main()
{
	myDCLL dcll;

	dcll.insertAtHead(15);
	dcll.insertAtTail(67);
	dcll.insertAtTail(-3);
	dcll.insertAtHead(85);
	
	
	dcll.deleteValue(15);

	dcll.displayFromHead();
	
	cout << "Display from Tail" << endl;
	dcll.displayFromTail();
	
	return 0;
}