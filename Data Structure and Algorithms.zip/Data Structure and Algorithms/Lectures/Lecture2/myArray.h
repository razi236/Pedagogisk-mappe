#pragma once
#include "Array.h"

class myArray:public Array
{
public:
	void addValue(int);
	int removeValue();
	myArray(int);
	//bool isEmpty();
	//bool isFull();
	void display();

};

int myArray::removeValue()
{
	currentSize--;
	return arr[currentSize];
}

void myArray::display()
{
	cout << "Max Size: " << maxSize << endl;
	cout << "Current Size: " << currentSize << endl;

	for (int i = 0; i < currentSize; i++)
	{
		cout << i << ". "<< arr[i] << endl;
	}
}

void myArray::addValue(int value)
{
	arr[currentSize] = value;
	currentSize++;
}

myArray::myArray(int s):Array(s)
{

}