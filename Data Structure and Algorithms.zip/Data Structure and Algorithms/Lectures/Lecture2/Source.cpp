#include "myArray.h"

int main()
{
	myArray obj(10);

	obj.addValue(15);
	obj.addValue(-3);
	obj.addValue(10);
	obj.addValue(99);

	cout << "Removed: " << obj.removeValue() << endl;
	cout << "Removed: " << obj.removeValue() << endl;


	obj.display();

	return 0;
}