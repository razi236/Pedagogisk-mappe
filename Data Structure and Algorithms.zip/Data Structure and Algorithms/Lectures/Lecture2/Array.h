#pragma once

#include <iostream>
using namespace std;

class Array
{
protected:
	int* arr;
	int currentSize;
	int maxSize;
public:
	virtual void addValue(int) = 0;
	virtual int removeValue() = 0;
	//virtual bool isEmpty() = 0;
	//virtual bool isFull() = 0;

	Array(int);

};

Array::Array(int size)
{
	arr = new int[size];
	maxSize = size;
	currentSize = 0;
}