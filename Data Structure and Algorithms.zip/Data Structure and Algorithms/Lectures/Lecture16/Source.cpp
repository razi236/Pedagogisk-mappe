#include <iostream>
using namespace std;

int fib(int n)
{
	if (n == 1)
		return 0;

	else if (n == 2)
		return 1;

	else if (n > 2)
		return fib(n - 1) + fib(n - 2);
}

int fact(int n)
{
	if (n > 0)
		return n * fact(n - 1);

	else if (n == 0)
		return 1;
}

int noOfDigits(int n)
{
	if (n == 0)
		return 0;

	else
		return 1 + noOfDigits(n / 10);
}

int sumOfDigits(int n)
{
	if (n == 0)
		return 0;

	else
		return (n%10) + sumOfDigits(n / 10);
}

void dec2bin(int n)
{
	if (n > 0)
	{
		dec2bin(n / 2);
		cout << n % 2;
	}
}

int main()
{
	dec2bin(11);
	return 0;
}