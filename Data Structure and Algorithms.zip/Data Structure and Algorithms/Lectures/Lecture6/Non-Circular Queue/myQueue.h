#pragma once
#include "Queue.h"

template <class T>
class myQueue:public Queue<T>
{
public:
	void enqueue(T);
	T dequeue();
	myQueue(int);
	bool isEmpty();
	bool isFull();
	void display();

};

template <class T>
bool myQueue<T>::isEmpty()		//O(1)
{
	if (Queue<T>::currentSize == 0)
		return true;

	else
		return false;
}


template <class T>
bool myQueue<T>::isFull()		//O(1)
{
	if (Queue<T>::currentSize == Queue<T>::maxSize)
		return true;

	else
		return false;
}

template <class T>			//O(n)
T myQueue<T>::dequeue()		
{
	if (!isEmpty())
	{
		T returningValue = Queue<T>::arr[0];

		for (int i = 0; i < Queue<T>::currentSize-1; i++)
			Queue<T>::arr[i] = Queue<T>::arr[i + 1];

		Queue<T>::currentSize--;

		return returningValue;
		
	}

	else
	{
		cout << "Queue is Empty" << endl;
		return NULL;
	}
	
}

template <class T>
void myQueue<T>::display()	//O(n)
{
	cout << "Max Size: " << Queue<T>::maxSize << endl;
	cout << "Current Size: " << Queue<T>::currentSize << endl;

	for (int i = 0; i < Queue<T>::currentSize; i++)
	{
		cout << i << ". "<< Queue<T>::arr[i] << endl;
	}
}

template <class T>
void myQueue<T>::enqueue(T value)	//O(1)
{
	if (!isFull())
	{
		Queue<T>::arr[Queue<T>::currentSize] = value;
		Queue<T>::currentSize++;
	}

	else

		cout << "Queue is Full (Overflow)" << endl;
}

template <class T>			//O(1)
myQueue<T>::myQueue(int s):Queue<T>(s)
{

}