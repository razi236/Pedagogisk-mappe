#pragma once
#include <iostream>
using namespace std;

template <class T>
class Queue
{
protected:
	T* arr;
	int currentSize;
	int maxSize;
public:
	virtual void enqueue(T) = 0;	 //void addValue(T)
	virtual T dequeue() = 0;		 //T removeValue()
	virtual bool isEmpty() = 0;
	virtual bool isFull() = 0;

	Queue(int);

};

template <class T>
Queue<T>::Queue(int size)
{
	arr = new T[size];
	maxSize = size;
	currentSize = 0;
}