#include "myQueue.h"

int main()
{
	myQueue<int> q(5);

	q.enqueue(15);
	q.enqueue(-3);
	q.enqueue(95);

	cout << "De-Queueud valued: " << q.dequeue() << endl;

	q.display();

	return 0;
}