#include "myQueue.h"

int main()
{
	myQueue<int> q(5);

	q.enqueue(15);
	q.enqueue(-3);
	q.enqueue(95);
	q.enqueue(870);
	q.enqueue(23);

	q.dequeue();
	q.dequeue();

	q.enqueue(100);
	q.enqueue(999);

	q.dequeue();
	q.dequeue();
	q.dequeue();
	q.dequeue();

	q.display();

	return 0;
}