#include "myLinkedList.h"

int main()
{
	myLinkedList obj;

	obj.insertAtTail(15);
	obj.insertAtTail(-3);
	obj.insertAtTail(100);
	obj.insertAtHead(999);

	obj.display();

}