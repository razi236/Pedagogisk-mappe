#pragma once
#include "Node.h"
#include <iostream>
using namespace std;

class LinkedList
{
protected:
	Node* tail;
public:
	virtual void insertAtTail(int) = 0;
	virtual void insertAtHead(int) = 0;

	LinkedList()
	{
		tail = nullptr;
	}
};