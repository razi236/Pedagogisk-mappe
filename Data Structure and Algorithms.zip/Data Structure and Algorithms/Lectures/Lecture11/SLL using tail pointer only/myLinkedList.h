#pragma once
#include "LinkedList.h"

class myLinkedList :public LinkedList
{
public:
	void insertAtTail(int value);
	void insertAtHead(int value);
	void display();

};

void myLinkedList::insertAtHead(int value)
{
	Node* nn = new Node;
	nn->data = value;
	nn->next = nullptr;

	if (tail == nullptr)
	{
		tail = nn;
		tail->next = tail;	// tail->next = nn;
	}

	else
	{
		nn->next = tail->next;
		tail->next = nn;
	}
}

void myLinkedList::display()
{
	if (tail == nullptr)
		cout << "LL is empty" << endl;

	else
	{
		Node* h = tail->next;

		while (1)
		{
			cout << h->data << endl;

			h = h->next;

			if (h == tail->next)
				break;
		
		}
	}
}


void myLinkedList::insertAtTail(int value)
{
	Node* nn = new Node;
	nn->data = value;
	nn->next = nullptr;

	if (tail == nullptr)
	{
		tail = nn;
		tail->next = tail;	// tail->next = nn;
	}

	else
	{
		nn->next = tail->next;
		tail->next = nn;
		tail = nn;
	}
}