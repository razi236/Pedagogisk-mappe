#include "myLinkedList.h"

int main()
{
	myLinkedList obj;
	obj.insertAtTail(15);

	cout << "Delete 15:" << obj.deleteValue(15) << endl;

	obj.display();
	return 0;
}