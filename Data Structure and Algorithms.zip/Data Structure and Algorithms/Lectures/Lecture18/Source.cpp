#include "BST.h"
using namespace std;

int main()
{
	BST bst1;
	
	bst1.insert(20);
	bst1.insert(10);
	bst1.insert(80);
	bst1.insert(70);
	bst1.insert(15);
	bst1.insert(14);
	bst1.insert(-5);
	bst1.insert(2);
	
	
	bst1.inorder();
	
	
	BST obj2;
	
	
	return 0;
}