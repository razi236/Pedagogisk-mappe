#include "Tree.h"

class BST:public Tree
{
	void INORDER(Node* p);
public:
	void insert(int value);
	void inorder();
};

void BST::INORDER(Node* p)
{
	if (p!=nullptr)
	{
		INORDER(p->left);
		cout << p->data << endl;
		INORDER(p->right);
	}
}

void BST::inorder()
{
	if (root == nullptr)
		cout << "Tree is empty"  << endl;
		
	else
		INORDER(root);
}

void BST::insert(int value)
{
	Node *n = new Node;
	n->left = nullptr;
	n->right = nullptr;
	n->data = value;
	
	if (root == nullptr)
	{
		root = n;
	}
	
	else
	{
		Node*t = root;
		
		while(1)
		{
			if (value<t->data)	//left child case
			{
				if (t->left==nullptr)	//insert the value 
				{
					t->left = n;
					break;
				}
				
				else
				{
					t = t->left;
				}
			}
			
			else				//right child case
			{
				if (t->right == nullptr)	//insert value
				{
					t->right = n;
					break;
				}
				
				else
				{
					t=t->right;
				}
				
			}
				
		}
	}
	
}