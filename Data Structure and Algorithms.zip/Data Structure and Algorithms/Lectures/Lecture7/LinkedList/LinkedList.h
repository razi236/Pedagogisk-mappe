#include "Node.h"
#include <iostream>
using namespace std;

class LinkedList
{
protected:
	Node* head;
	Node* tail;
public:
	LinkedList();
	virtual void insert(int) = 0;
};

LinkedList::LinkedList()
{
	head = nullptr;
	tail = nullptr;
}