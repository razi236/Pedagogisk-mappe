#include "LinkedList.h"

class myLinkedList:public LinkedList 
{
public:
	void insert(int value);
};

void myLinkedList::insert(int value)
{

	Node* newNode = new Node;
	newNode->data = value;
	newNode->next = nullptr;


	if (head == nullptr && tail == nullptr)
	{
		head = newNode;
		tail = newNode;
	}

	else
	{
		tail->next = newNode;
		tail = newNode;
	}
}

