#include "myLinkedList.h"

int main()
{
	myLinkedList obj;
	obj.insert(15);
	obj.insert(-3);
	obj.insert(99);
	return 0;
}