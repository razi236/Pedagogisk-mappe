#include "BST.h"
using namespace std;

int main()
{
	BST bst;
	
	bst.insert(20);
	return 0;
}