#include "Tree.h"

class BST:public Tree
{
public:
	void insert(int value);
};

void BST::insert(int value)
{
	Node *n = new Node;
	n->left = nullptr;
	n->right = nullptr;
	n->data = value;
	
	if (root == nullptr)
	{
		root = n;
	}
	
	else
	{
		//start writing from here
	}
	
}