#include "LinkedList.h"

class myLinkedList:public LinkedList 
{
public:
	void insertAtTail(int value);
	void insertAtHead(int value);
	void display();

	int deleteFromHead();
	int deleteFromTail();
	bool deleteValue(int value);
};

bool myLinkedList::deleteValue(int value)
{
	if (head == nullptr)
		return false;

	if (head->data == value)
	{
		if (head->next == nullptr)	//single value case
		{
			delete head;
			head = nullptr;
			
		}

		else
		{
			Node* t = head;
			head = head->next;
			delete t;
			t = nullptr;
		}

		return true;
	}

	else
	{
		Node* t = head;

		while (1)
		{
			if (t->next->data == value)
			{
				Node* tt = t->next;
				t->next = t->next->next;
				delete tt;
				tt = nullptr;
				return true;

			}

			t = t->next;

			if (t->next == nullptr)
				return false;
		}
	}
}

int myLinkedList::deleteFromTail()
{

	if (head == nullptr && tail == nullptr)
	{
		cout << "Empty LL" << endl;
		return NULL;
	}

	else if (head == tail) //single Node case
	{
		int rv = head->data;
		delete head;
		head = nullptr;
		tail = nullptr;
		return rv;
	}

	else
	{
		Node* t = head;

		while (1)
		{
			if (t->next == tail)
				break;

			t = t->next;
		}

		int rv = tail->data;
		delete tail;
		tail = t;
		t->next = nullptr;
		return rv;
	}
}

int myLinkedList::deleteFromHead()
{

	if (head == nullptr && tail == nullptr)
	{
		cout << "Empty LL" << endl;
		return NULL;
	}

	else if (head == tail) //single Node case
	{
		int rv = head->data;
		delete head;
		head = nullptr;
		tail = nullptr;
		return rv;
	}

	else
	{
		Node* temp = head;
		head = head->next;
		int rv = temp->data;
		delete temp;
		temp = nullptr;
		return rv;
	}
}

void myLinkedList::display()
{
	if (head == nullptr && tail == nullptr)
		cout << "LL is empty" << endl;

	else
	{
		Node* temp = head;

		while (1)
		{
			cout << temp->data << endl;
			temp = temp->next;

			if (temp == nullptr)
				break;
		}
	}
}

void myLinkedList::insertAtHead(int value)
{

	Node* newNode = new Node;
	newNode->data = value;
	newNode->next = nullptr;


	if (head == nullptr && tail == nullptr)
	{
		head = newNode;
		tail = newNode;
	}

	else
	{
		newNode->next = head;
		head = newNode;
	}
}

void myLinkedList::insertAtTail(int value)
{

	Node* newNode = new Node;
	newNode->data = value;
	newNode->next = nullptr;


	if (head == nullptr && tail == nullptr)
	{
		head = newNode;
		tail = newNode;
	}

	else
	{
		tail->next = newNode;
		tail = newNode;
	}
}

