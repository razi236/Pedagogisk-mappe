#include "myLinkedList.h"

int main()
{
	myLinkedList obj;
	obj.insertAtTail(15);
	obj.insertAtTail(-3);
	obj.insertAtTail(99);

	obj.insertAtHead(10);

	cout << "Delete 15:" << obj.deleteValue(15) << endl;

	obj.display();
	return 0;
}