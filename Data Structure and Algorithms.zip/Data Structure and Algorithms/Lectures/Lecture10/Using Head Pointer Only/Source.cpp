#include "myLinkedList.h"

int main()
{
	myLinkedList obj;

	obj.insertSorted(15);
	obj.insertSorted(-3);
	obj.insertSorted(-6);
	obj.insertSorted(10);
	obj.insertSorted(-9);
	obj.insertSorted(5);
	obj.insertSorted(99);
	
	cout << obj.deleteValue(-9);
	cout << obj.deleteValue(15);
	cout << obj.deleteValue(2);

	cout << endl;

	obj.display();

	//insert sorted nullptr case is still left (last value to be inserted)


	return 0;
}