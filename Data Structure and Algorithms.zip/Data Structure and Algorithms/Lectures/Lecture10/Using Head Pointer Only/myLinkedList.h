#pragma once
#include "LinkedList.h"

class myLinkedList:public LinkedList
{
public:
	void insertAtTail(int value);
	void insertSorted(int value);
	void display();
	bool deleteValue(int value);
};

bool myLinkedList::deleteValue(int value)
{
	if (head == nullptr)
		return false;

	if (head->data == value)
	{
		if (head->next == nullptr)	//single value case
		{
			delete head;
			head = nullptr;
			
		}

		else
		{
			Node* t = head;
			head = head->next;
			delete t;
			t = nullptr;
		}

		return true;
	}

	else
	{
		Node* t = head;

		while (1)
		{
			if (t->next->data == value)
			{
				Node* tt = t->next;
				t->next = t->next->next;
				delete tt;
				tt = nullptr;
				return true;

			}

			t = t->next;

			if (t->next == nullptr)
				return false;
		}
	}
}

void myLinkedList::display()
{
	if (head == nullptr)
		cout << "LL is empty" << endl;

	else
	{
		Node* temp = head;

		while (1)
		{
			cout << temp->data << endl;
			temp = temp->next;

			if (temp == nullptr)
				break;
		}
	}
}

void myLinkedList::insertSorted(int value)
{
	bool flag = true;

	Node* nn;
	nn = new Node;
	nn->data = value;
	nn->next = nullptr;

	if (head == nullptr)
	{
		head = nn;
	}

	else
	{
		if (value <= head->data) //value to be inserted before head
		{
			nn->next = head;
			head = nn;
		}

		else
		{
			Node* t = head;

			while (1)
			{
				if (t->next->data >= value)
				{
					break;
				}

				t = t->next;

				if (t->next == nullptr)	//last node case
				{
					t->next = nn;
					flag = false;
					break;
				}
			}

			if (flag)
			{
				nn->next = t->next;
				t->next = nn;
			}
		}
	}
}

void myLinkedList::insertAtTail(int value)
{
	Node* nn;
	nn = new Node;
	nn->data = value;
	nn->next = nullptr;

	if (head == nullptr)
	{
		head = nn;
	}

	else
	{
		Node* t = head;

		while (1)
		{
			if (t->next == nullptr)
				break;

			t = t->next;
		}

		t->next = nn;

	}
}