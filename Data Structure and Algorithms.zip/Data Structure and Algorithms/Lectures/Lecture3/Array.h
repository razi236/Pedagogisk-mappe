#pragma once
#include <iostream>
using namespace std;

template <class T>
class Array
{
protected:
	T* arr;
	int currentSize;
	int maxSize;
public:
	virtual void addValue(T) = 0;
	virtual T removeValue() = 0;
	//virtual bool isEmpty() = 0;
	//virtual bool isFull() = 0;

	Array(int);

};

template <class T>
Array<T>::Array(int size)
{
	arr = new T[size];
	maxSize = size;
	currentSize = 0;
}