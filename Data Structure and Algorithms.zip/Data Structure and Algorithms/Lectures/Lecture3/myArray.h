#pragma once
#include "Array.h"

template <class T>
class myArray:public Array<T>
{
public:
	void addValue(T);
	T removeValue();
	myArray(int);
	//bool isEmpty();
	//bool isFull();
	void display();

};

template <class T>
T myArray<T>::removeValue()		//O(1)
{
	Array<T>::currentSize--;
	return Array<T>::arr[Array<T>::currentSize];
}

template <class T>
void myArray<T>::display()	//O(n)
{
	cout << "Max Size: " << Array<T>::maxSize << endl;
	cout << "Current Size: " << Array<T>::currentSize << endl;

	for (int i = 0; i < Array<T>::currentSize; i++)
	{
		cout << i << ". "<< Array<T>::arr[i] << endl;
	}
}

template <class T>
void myArray<T>::addValue(T value)	//O(1)
{
	Array<T>::arr[Array<T>::currentSize] = value;
	Array<T>::currentSize++;
}

template <class T>
myArray<T>::myArray(int s):Array<T>(s)
{

}