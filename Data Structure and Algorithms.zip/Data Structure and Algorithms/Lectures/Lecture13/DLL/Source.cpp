#include "myDLL.h"

int main()
{
	myDLL dll;

	dll.insertSorted(85);
	dll.insertSorted(99);
	dll.insertSorted(1);
	dll.insertSorted(50);
	dll.insertSorted(90);

	dll.displayFromHead();
	
	return 0;
}