#pragma once
#include "LinkedList.h"

class myDCLL :public LinkedList
{
public:
	void insertAtTail(int value);
	void insertAtHead(int value);
	void displayFromHead();
	void displayFromTail();
//	bool deleteValue(int value);
	void insertSorted(int value);
};



void myDCLL::displayFromTail()
{
	if (tail == nullptr)
		cout << "DLL is empty" << endl;

	else
	{
		Node* t = tail;

		while (1)
		{
			cout << t->data << endl;

			if (t->prev == tail)
				break;

			t = t->prev;

		}
	}
}

void myDCLL::displayFromHead()
{
	if (tail == nullptr)
		cout << "DLL is empty" << endl;

	else
	{
		Node* t = tail->next;

		while (1)
		{
			cout << t->data << endl;

			if (t->next == tail->next)
				break;

			t = t->next;

		}
	}
}

void myDCLL::insertAtTail(int value)
{
	Node* nn = new Node;
	nn->data = value;
	nn->next = nullptr;
	nn->prev = nullptr;

	if ( tail == nullptr)
	{
		tail = nn;
		tail->next = nn;
		tail->next = tail->next;
		tail->next->prev = tail;

	}

	else
	{
		nn->prev = tail;	//why not tail->next?
		nn->next = tail->next;
		tail->next = nn;
		tail->next->prev = nn;
		tail = nn;

	}
}

void myDCLL::insertAtHead(int value)
{
	Node* nn = new Node;
	nn->data = value;
	nn->next = nullptr;
	nn->prev = nullptr;

	if (  tail == nullptr)
	{
		
	}

	else
	{
		
	}
}

void myDCLL::insertSorted(int value)
{


	if ( tail == nullptr)
	{
		Node* nn = new Node;
		nn->data = value;
		nn->next = nullptr;
		nn->prev = nullptr;

		tail->next = nn;
		tail = nn;
	}

	else if (value >= tail->next->data)
		insertAtHead(value);

	else if (value <= tail->data)
		insertAtTail(value);

	else
	{
		Node* nn = new Node;
		nn->data = value;
		nn->next = nullptr;
		nn->prev = nullptr;

		Node* t = tail->next;

		while (1)
		{
			if (value >= t->next->data && value < t->data)
			{
				nn->prev = t;
				nn->next = t->next;
				t->next->prev = nn;
				t->next = nn;
				break;
			}

			t = t->next;

		}
	}
}

