#include "myDCLL.h"

int main()
{
	myDCLL dcll;

	dcll.insertAtTail(15);
	dcll.insertAtTail(67);
	dcll.insertAtTail(-3);
	
	
	dcll.displayFromHead();
	
	return 0;
}