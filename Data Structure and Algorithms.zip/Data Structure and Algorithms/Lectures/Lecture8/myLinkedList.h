#include "LinkedList.h"

class myLinkedList:public LinkedList 
{
public:
	void insertAtTail(int value);
	void insertAtHead(int value);
	void display();

	int deleteFromHead();
	int deleteFromTail();
};

int myLinkedList::deleteFromTail()
{

	if (head == nullptr && tail == nullptr)
	{
		cout << "Empty LL" << endl;
		return NULL;
	}

	else if (head == tail) //single Node case
	{
		int rv = head->data;
		delete head;
		head = nullptr;
		tail = nullptr;
		return rv;
	}

	else
	{
		Node* t = head;

		while (1)
		{
			if (t->next == tail)
				break;

			t = t->next;
		}

		int rv = tail->data;
		delete tail;
		tail = t;
		t->next = nullptr;
		return rv;
	}
}

int myLinkedList::deleteFromHead()
{

	if (head == nullptr && tail == nullptr)
	{
		cout << "Empty LL" << endl;
		return NULL;
	}

	else if (head == tail) //single Node case
	{
		int rv = head->data;
		delete head;
		head = nullptr;
		tail = nullptr;
		return rv;
	}

	else
	{
		Node* temp = head;
		head = head->next;
		int rv = temp->data;
		delete temp;
		temp = nullptr;
		return rv;
	}
}

void myLinkedList::display()
{
	if (head == nullptr && tail == nullptr)
		cout << "LL is empty" << endl;

	else
	{
		Node* temp = head;

		while (1)
		{
			cout << temp->data << endl;
			temp = temp->next;

			if (temp == nullptr)
				break;
		}
	}
}

void myLinkedList::insertAtHead(int value)
{

	Node* newNode = new Node;
	newNode->data = value;
	newNode->next = nullptr;


	if (head == nullptr && tail == nullptr)
	{
		head = newNode;
		tail = newNode;
	}

	else
	{
		newNode->next = head;
		head = newNode;
	}
}

void myLinkedList::insertAtTail(int value)
{

	Node* newNode = new Node;
	newNode->data = value;
	newNode->next = nullptr;


	if (head == nullptr && tail == nullptr)
	{
		head = newNode;
		tail = newNode;
	}

	else
	{
		tail->next = newNode;
		tail = newNode;
	}
}

