#pragma once
#include "Stack.h"

template <class T>
class myStack:public Stack<T>
{
public:
	void push(T);
	T pop();
	T top();	//peek
	myStack(int);
	bool isEmpty();
	bool isFull();
	void display();

};

template <class T>
T myStack<T>::top()		//O(1)
{
	if (!isEmpty())
	{
		return Stack<T>::arr[Stack<T>::currentSize - 1];
	}

	else
	{
		cout << "Stack is Empty" << endl;
		return NULL;
	}

}


template <class T>
bool myStack<T>::isEmpty()		//O(1)
{
	if (Stack<T>::currentSize == 0)
		return true;

	else
		return false;
}


template <class T>
bool myStack<T>::isFull()		//O(1)
{
	if (Stack<T>::currentSize == Stack<T>::maxSize)
		return true;

	else
		return false;
}

template <class T>
T myStack<T>::pop()		//O(1)
{
	if (!isEmpty())
	{
		Stack<T>::currentSize--;
		return Stack<T>::arr[Stack<T>::currentSize];
	}

	else
	{
		cout << "Stack is Empty" << endl;
		return NULL;
	}
	
}

template <class T>
void myStack<T>::display()	//O(n)
{
	cout << "Max Size: " << Stack<T>::maxSize << endl;
	cout << "Current Size: " << Stack<T>::currentSize << endl;

	for (int i = 0; i < Stack<T>::currentSize; i++)
	{
		cout << i << ". "<< Stack<T>::arr[i] << endl;
	}
}

template <class T>
void myStack<T>::push(T value)	//O(1)
{
	if (!isFull())
	{
		Stack<T>::arr[Stack<T>::currentSize] = value;
		Stack<T>::currentSize++;
	}

	else

		cout << "Stack is Full (Overflow)" << endl;
}

template <class T>			//O(1)
myStack<T>::myStack(int s):Stack<T>(s)
{

}