#include "myStack.h"

int main()
{
	myStack<float> s(5);

	s.push(10.2);
	s.push(-3);
	s.push(99.5);
	s.push(-65.33);
	s.push(25);

	//cout << "Removed Value: " << s.pop() << endl;
	cout << "Topped Value: " << s.top() << endl;

	s.display();


	return 0;
}