#include <iostream>
#include "Printer.h"
using namespace std;

int Printer::count = 0;

int main()
{

	Printer p1(157);
	Printer p2 = p1;


	cout << "p1 = " <<  p1 << endl;
	cout << "p2 = " << p2 << endl;





	/*
	Printer* p1 = new Printer[100];
	cout << Printer::getCount() << endl;
	delete []p1;
	p1 = nullptr;

	cout << Printer::getCount() << endl;
	*/


	/*
	cout << Printer::getCount() << endl;

	Printer p1;
	cout << p1.getCount() << endl;
	Printer p2 = p1;

	cout << Printer::getCount() << endl;

	*/
	/*
	cout << Printer::getCount() << endl;

	Printer p1;

	cout << Printer::getCount() << endl;

	Printer p2;

	cout << Printer::getCount() << endl;


	*/
	/*
	Printer arr[3];

	Printer xyz;

	xyz.setCount(15); //count = 15

	cout << arr[1].getCount() << endl; //15

	arr[2].setCount(arr[0].getCount() + 1); //count = 16

	cout << xyz.getCount() << endl; //16
	*/
	return 0;
}