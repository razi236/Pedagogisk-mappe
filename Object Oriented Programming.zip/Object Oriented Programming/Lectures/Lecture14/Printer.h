#pragma once
#include <iostream>
using namespace std;
class Printer
{
	static int count;
	int* instance;
public:
	
	static void setCount(int c);
	static int getCount();
	Printer(int rhs=1);
	Printer& operator = (const Printer&);
	Printer(const Printer&);
	~Printer();
	void display() const;

	friend ostream& operator<<(ostream& out, const Printer& p)
	{
		out << *p.instance;
		return out;
	}
};

