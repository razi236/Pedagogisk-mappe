#pragma once
class Brake
{
public:
	Brake();
	~Brake();
};

