#pragma once
#include"Engine.h"
#include "Brake.h"
#include "AC.h"
class Car
{
	Engine e; //composition
	Brake b[4]; //composition
	AC* ac; //composition OR aggregation
public:
	Car();
	~Car();
};

