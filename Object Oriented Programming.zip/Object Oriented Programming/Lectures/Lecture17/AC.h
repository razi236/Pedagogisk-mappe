#pragma once
class AC
{
public:
	AC();
	~AC();
};

