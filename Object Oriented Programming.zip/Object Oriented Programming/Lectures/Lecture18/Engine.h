#pragma once
#include <iostream>
using namespace std;
class Engine
{
public:
	Engine();
	~Engine();
};

