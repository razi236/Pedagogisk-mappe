#include "Engine.h"



Engine::Engine()
{
	cout << "Engine()" << endl;
}


Engine::~Engine()
{
	cout << "~Engine()" << endl;
}
