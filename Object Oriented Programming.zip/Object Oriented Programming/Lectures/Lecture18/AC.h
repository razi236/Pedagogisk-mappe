#pragma once
#include <iostream>
using namespace std;

class AC
{
public:
	AC();
	~AC();
};

