#include "Car.h"

int main()
{
	
	cout << "Welcome to my LIFE" << endl;
	
	int choice = 0;
	Car *c = nullptr;

	while(1)
	{
		cout << "1. Let's buy a car" << endl;
		cout << "2. Sell that car" << endl;
		cout << "3. Add AC" << endl;
		cout << "4. Delete AC" << endl;
		cout << "5. Exit" << endl;
		cout << "6. Add Dual AC" << endl;
		
		cout << "Enter a choice..." << endl;
		
		cin >> choice;
		
		if (choice == 1)
			c = new Car;

			
		else if (choice == 2)
		{
			if (c!=nullptr)
			{
				delete c;
				c = nullptr;
			}
			
			else 
				cout << "Buy a car first" << endl;
		}
			
		else if (choice == 3)
		{
			if (c==nullptr)
				cout << "Window shopping, okay!" << endl;
			
			else
			{
				c->addAC(1);
			}
				
		}
		
		else if (choice == 4)
		{
			if (c==nullptr)
				cout << "You Joking!!!" << endl;
			
			else
			{
				c->removeAC();
			}
		}
		
		else if (choice == 5)
			break;
		
		else if (choice == 6)
		{
			if (c==nullptr)
				cout << "Window shopping, okay!" << endl;
			
			else
			{
				c->addAC(2);
			}
				
		}
			
		else
			cout << "enter a valid choice" << endl;
	}
	
	return 0;
}