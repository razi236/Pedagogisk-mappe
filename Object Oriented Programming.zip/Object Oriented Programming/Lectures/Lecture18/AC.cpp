#include "AC.h"



AC::AC()
{
	cout << "AC()" << endl;
}


AC::~AC()
{
	cout << "~AC()" << endl;
}
