#include "Brake.h"



Brake::Brake()
{
	cout << "Brake()" << endl;
}


Brake::~Brake()
{
	cout << "~Brake()" << endl;
}
