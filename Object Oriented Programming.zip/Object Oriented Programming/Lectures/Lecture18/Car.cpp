#include "Car.h"

void Car::addAC(int no)
{
	if (no>0 && no<=2)
		ac = new AC[no];
}

void Car::removeAC()
{
	delete ac;
	ac = nullptr;
}


Car::Car()
{
	
	e = new Engine();
	b = new Brake[4];
	cout << "Car()" << endl;
}


Car::~Car()
{
	cout << "~Car()" << endl;
	delete e;
	e = nullptr;
	delete [] b;
	b = nullptr;
}
