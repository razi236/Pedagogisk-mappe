#include "Circle.h"

int main()
{
	Circle c1;

	Circle c2(4.8);

	Circle c3 = c2;

	cout << c2.area(154) << endl;

	c2.display();
	cout << c2.diameter() << endl;
	cout << c2.circumference() << endl;

	return 0;
}