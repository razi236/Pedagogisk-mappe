#include"Student.h"

int main()
{
	Student one;

	one.display();

	

	/*Student obj;

	char temp[4] = { 'A', 'l', 'i', '\0' };

	cout << temp << endl;

	obj.setName(temp);

	cout << obj.getName() << endl;

	temp[0] = 'X';

	cout << obj.getName() << endl;*/

	return 0;
}