#pragma once
#include "Shape.h"
class Triangle:protected Shape
{
public:
	Triangle();
	Triangle(double, double);
	~Triangle();
	void d();	//wraPPER

	double a();	//WRA	PPER
};

