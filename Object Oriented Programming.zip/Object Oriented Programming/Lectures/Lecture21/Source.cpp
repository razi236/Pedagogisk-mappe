#include <iostream>
#include "Rectangle.h"
#include "Triangle.h"
using namespace std;

int main()
{
	Triangle t;
	t.d();
	




	//Rectangle r;
	//r.height = 15;
	//r.display();
	//r.width = 5;
	//r.length = 10;

	return 0;
}