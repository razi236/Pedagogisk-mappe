#include "Shape.h"

Shape::Shape()
{
	cout << "Shape()" << endl;
	this->length = 0;
	this->width = 0;
	this->height = 0;
}

Shape::Shape(double length, double width, double height)
{
	cout << "Shape(double, double, double)" << endl;
	this->length = length;
	this->width = width;
	this->height = height;
}


Shape::~Shape()
{
	cout << "~Shape()" << endl;
}

double Shape::volume()
{
	cout << "Shape::volume()" << endl;
	return length*width*height;
}

double Shape::area()
{
	cout << "Shape::area()" << endl;
	return length*width;
}

void Shape::display()
{
	cout << "Length = " << this->length << endl;
	cout << "Width = " << this->width << endl;
	cout << "Height = " << this->height << endl;
}