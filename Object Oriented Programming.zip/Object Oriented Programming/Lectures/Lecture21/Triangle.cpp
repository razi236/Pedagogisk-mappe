#include "Triangle.h"

double Triangle::a()
{
	return area();
}

void Triangle::d()
{
	display();
}

Triangle::Triangle()
{
	cout << "Triangle()" << endl;
}

Triangle::Triangle(double w, double h)
{
	cout << "Triangle(double, double)" << endl;
}


Triangle::~Triangle()
{
	cout << "~Triangle()" << endl;
}
