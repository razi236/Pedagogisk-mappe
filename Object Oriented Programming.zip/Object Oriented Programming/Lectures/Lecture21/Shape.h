#pragma once
#include <iostream>
using namespace std;

class Shape
{
	double length;
	double volume();
protected:
	double width;
	double area();
public:
	double height;
	Shape();
	Shape(double, double, double);
	~Shape();
	void display();
};

