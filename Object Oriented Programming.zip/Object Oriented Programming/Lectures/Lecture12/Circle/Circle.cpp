#include "Circle.h"

Circle& Circle::operator=(const Circle& obj)
{
	if (this != &obj)
	{
		*radius = *obj.radius;
	}

	return *this;
}

Circle::Circle(const Circle& other):pi((double)(22)/7)
{
	radius = new double;
	*radius = *other.radius;
	//temp = 100;
}

Circle::Circle(double r):pi(static_cast<double>(22)/7)
{
	radius = new double;
	*radius = r;
	//temp = 45;
}

double Circle::area()const 
{
	//radius = new double;
	//*radius = 150;
	//temp = 99;
	return pi**radius**radius;
}

double Circle::circumference() const
{
	return 2 * pi** radius;
}

double Circle::diameter() const
{
	return 2 * *radius;
}

void Circle::display() const
{
	cout << "Radius = " << *radius << endl;
	cout << "Pi = " << pi << endl;

}



Circle::~Circle()
{
	delete radius;
}
