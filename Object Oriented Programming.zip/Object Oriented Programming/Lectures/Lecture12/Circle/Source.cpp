#include "Circle.h"

int main()
{
	Circle c1;

	Circle c2(4.8);

	

	c1 = c2;

	c1.display();
	c2.display();

	return 0;
}