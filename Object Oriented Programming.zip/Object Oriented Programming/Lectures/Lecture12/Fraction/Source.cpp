#include "Fraction.h"

int main()
{


	Fraction one(3, 2);

	one = one;

	cin >> one;
	cout << one << endl;

	

	/*
	Fraction one(3, 2);
	Fraction two;

	two = one++;

	one.display();
	two.display();
	*/
	/*
	Fraction one(1, 2);

	Fraction two;

	two = -one;

	two.display();

	/*
	Fraction one(6, 10);
	Fraction two(3, 5);
	Fraction three;
	
	if (one == two)
		cout << "Yes" << endl;
	else
		cout << "No" << endl;
		*/
	return 0;
}