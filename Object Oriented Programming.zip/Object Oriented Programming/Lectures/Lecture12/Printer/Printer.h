#pragma once
#include <iostream>
using namespace std;
class Printer
{
	int* instance;
public:
	Printer(int rhs);
	Printer& operator = (const Printer&);
	Printer(const Printer&);
	~Printer();

	friend ostream& operator<<(ostream& out, const Printer& p)
	{
		out << *p.instance;
		return out;
	}
};

