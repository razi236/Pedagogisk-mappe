#include "Printer.h"

Printer& Printer::operator = (const Printer& rhs)
{
	if (this != &rhs)
	{
		*instance = *rhs.instance;
	}

	return *this;
}

Printer::Printer(const Printer& rhs)
{
	instance = new int;
	*instance = *rhs.instance;
}

Printer::Printer(int value)
{
	instance = new int;
	*instance = value;
}


Printer::~Printer()
{
	delete instance;
}
