#include "Student.h"

void Student::display()
{
	cout << "Age = " << age << endl;
	cout << "CGPA = " << CGPA << endl;
	//cout << "Name = " << name << endl;
}

void Student::setAge(int a)
{
	age = a;
}

void Student::setCGPA(float cgpa)
{
	CGPA = cgpa;
}


//setter of name - this is WRONG:
void Student::setName(char* n)
{
	name = n;
}

float Student::getCGPA()
{
	return CGPA;
}

//getter of name - this is INCORRECT:
char* Student::getName()
{
	return name;
}

int Student::getAge()
{
	return age;
}

void Student::toStudy(int money)
{
	cout << "To make money halal" << endl;
	cout << money << endl;
}

char Student::earnGrades(float marks)
{
	if (marks >= 86)
	{
		CGPA = 4.00;
		return'A';
	}

	else if (marks < 50)
	{
		CGPA = 0;
		return'F';
	}

	else
	{
		CGPA = 2.33;
		return 'C';
	}
		
}