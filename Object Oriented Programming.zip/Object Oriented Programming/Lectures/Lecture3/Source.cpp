#include"Student.h"

int main()
{
	Student one, two;		//Student one;
							//Student two;
	
	one.setAge(22);
	two.setAge(19);

	one.setCGPA(2.2);
	two.setCGPA(3.92);

	cout << one.getAge() << endl;
	cout << two.getAge() << endl;


	cout << "Display Function: " << endl;
	one.display();

	return 0;
}