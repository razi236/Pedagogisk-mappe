#include <iostream>
#include "Rectangle.h"
#include "Triangle.h"
#include "Square.h" 
using namespace std;

int main()
{
	Triangle t(6, 5);
	t.display();
	cout << t.area() <<endl;
	//cout << t.Shape::area() << endl;


	//Square sq(6.5);
	//sq.display();
	//cout << sq.area() << endl;

	//Rectangle r(5.1, 6.6);
	//r.display();
	//cout << r.area() << endl;


	//Square s;
	//s.display();

	//Triangle t;
	//t.d();

	//Rectangle r;
	//r.display();

	//Triangle t;
	//t.display();
	




	//Rectangle r;
	//r.height = 15;
	//r.display();
	//r.width = 5;
	//r.length = 10;

	return 0;
}