#pragma once
#include <iostream>
using namespace std;

class Shape
{
protected:
	double width;
	double length;
	double height;	
public:
	double area();
	double volume();
	Shape();
	Shape(double, double, double);
	~Shape();
	void display();
};

