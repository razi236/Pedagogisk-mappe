#include "Triangle.h"

double Triangle::area()
{
	cout << "Calling Area of Shape first: " << endl;
	cout << Shape::area() << endl;
	cout << "Triangle::area()" << endl;
	return 1.0 / 2 * width*height;
}

/*
double Triangle::a()
{
	return area();
}

void Triangle::d()
{
	display();
}*/

Triangle::Triangle()
{
	cout << "Triangle()" << endl;
}

Triangle::Triangle(double w, double h) :Shape(0,w,h)
{
	cout << "Triangle(double, double)" << endl;	

}


Triangle::~Triangle()
{
	cout << "~Triangle()" << endl;
}
