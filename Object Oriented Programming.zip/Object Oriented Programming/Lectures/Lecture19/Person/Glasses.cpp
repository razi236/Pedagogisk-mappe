#include "Glasses.h"

void Glasses::seeClearly()
{
	cout << "seeClearly()" << endl;
}

Glasses::Glasses(double p)
{
	cout << "Glasses(double)" << endl;
}



Glasses::Glasses()
{
	cout << "Glasses()" << endl;
}


Glasses::~Glasses()
{
}
