#pragma once
#include <iostream>
using namespace std;
class Glasses
{
	double power;
public:
	Glasses();
	Glasses(double p);
	void seeClearly();
	~Glasses();
};

