#include "Heart.h"

void Heart::toPumpBlood()
{
	cout << "toPumpBlood()" << endl;
}

Heart::Heart()
{
	cout << "Heart()" << endl;
}

Heart::Heart(int v)
{
	cout << "Heart(int)" << endl;
}


Heart::~Heart()
{
	cout << "~Heart()" << endl;
}
