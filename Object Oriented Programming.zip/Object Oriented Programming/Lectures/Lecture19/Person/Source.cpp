#include "Person.h"

int main()
{
	Person p;
	p.callingPumpBloodFunctionOfHeart();
	return 0;
}