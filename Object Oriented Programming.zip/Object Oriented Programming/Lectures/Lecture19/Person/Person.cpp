#include "Person.h"

void Person::callingPumpBloodFunctionOfHeart()
{
		h.toPumpBlood();
}

void Person::toSee()
{
	cout << "toSee()" << endl;
}

Person::Person(int i)
{
	cout << "Person(int)" << endl;
}

Person::Person():h(65)
{
	cout << "Person()" << endl;
}


Person::~Person()
{
	cout << "~Person()" << endl;
}
