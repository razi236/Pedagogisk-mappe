#pragma once
#include "Heart.h"
#include "Glasses.h"
#include <iostream>
using namespace std;
class Person
{
	Heart h;
	Glasses* g;
	int eyes;
public:
	Person();
	Person(int e);
	~Person();
	void toSee();
	void callingPumpBloodFunctionOfHeart();	//wrapper function
	
};

