#pragma once
#include <iostream>
using namespace std;
class Heart
{
	int veins;
public:
	Heart(int v);
	Heart();
	void toPumpBlood();
	~Heart();
};

