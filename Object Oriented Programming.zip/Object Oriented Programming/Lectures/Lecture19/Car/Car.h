#pragma once
#include <iostream>
using namespace std;
#include"Engine.h"
#include "Brake.h"
#include "AC.h"
class Car
{
	Engine *e; //composition
	Brake *b; //composition
	AC* ac; //aggregation
public:
	Car();
	~Car();
	
	void addAC(int no, AC* outsideAC);
	void removeAC();
};

