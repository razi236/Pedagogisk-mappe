#include <iostream>
using namespace std;

template <typename Gen>
Gen sum(Gen a, Gen b)
{
	return a + b;
}

template <class T>
void display(T value)
{
	cout << value << endl;
}

int main()
{
	int int_var = 155;
	float  float_var = 3.2;
	string string_var = "dumb";
	char char_var = 'A';
	display(int_var);
	display(float_var);
	display(string_var);
	display(char_var);

	int first = 15, second = 17;
	cout << sum(first, second) << endl;

	float firstF = 1.05, secondF = 1.7;
	cout << sum(firstF, secondF) << endl;

	char firstC = 'A', secondC = ' ';
	cout << sum(firstC, secondC) << endl;


	return 0;
}