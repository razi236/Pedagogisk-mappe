#pragma once
#include <iostream>
using namespace std;

class Fraction
{
	int num;
	int den;
public:
	Fraction();
	Fraction(int, int);
	void display();

	Fraction(const Fraction& obj);

	Fraction operator+(const Fraction &obj);

	Fraction& operator=(const Fraction& obj);
};

