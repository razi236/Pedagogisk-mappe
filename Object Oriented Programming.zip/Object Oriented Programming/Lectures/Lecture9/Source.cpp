#include "Fraction.h"

int main()
{
	Fraction one(1, 2);
	Fraction two(3, 5);
	Fraction three;
	
	//three.operator=(one.operator+(two)); //one+two

	three = one;	//three.operator=(one);

	three.display();
	return 0;
}