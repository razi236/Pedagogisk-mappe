#pragma once
#include "Cricketer.h"
#include <iostream>
using namespace std;
class Batter:virtual public Cricketer
{
public:
	Batter();
	~Batter();
	void batting();
};

