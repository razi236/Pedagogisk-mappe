#include "Bowler.h"

void Bowler::bowling()
{
	cout << "I am bowling()" << endl;
}

Bowler::Bowler()
{
	cout << "Bowler()" << endl;
}


Bowler::~Bowler()
{
	cout << "~Bowler()" << endl;
}
