#pragma once
#include "Cricketer.h"
#include <iostream>
using namespace std;

class Bowler :virtual public Cricketer
{
public:
	Bowler();
	~Bowler();
	void bowling();
};

