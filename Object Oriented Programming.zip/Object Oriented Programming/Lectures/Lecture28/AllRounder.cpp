#include "AllRounder.h"

AllRounder::AllRounder()
{
	cout << "AllRounder()" << endl;

	//number = 88;
}

AllRounder::~AllRounder()
{
	cout << "~AllRounder()" << endl;
}
