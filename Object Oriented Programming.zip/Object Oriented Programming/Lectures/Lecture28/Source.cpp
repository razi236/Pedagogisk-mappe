#include "AllRounder.h"

int main()
{
	AllRounder lala;
	lala.display();
	return 0;
}