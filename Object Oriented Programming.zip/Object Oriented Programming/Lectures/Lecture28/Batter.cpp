#include "Batter.h"

void Batter::batting()
{
	cout << "I am batting()" << endl;
}

Batter::Batter()
{
	cout << "Batter()" << endl;
}


Batter::~Batter()
{
	cout << "~Batter()" << endl;
}
