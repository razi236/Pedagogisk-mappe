#include "Cricketer.h"

void Cricketer::display()
{
	cout << "Display in Cricketer" << endl;

}

Cricketer::Cricketer()
{
	cout << "Cricketer()" << endl;
}


Cricketer::~Cricketer()
{
	cout << "~Cricketer()" << endl;
}
