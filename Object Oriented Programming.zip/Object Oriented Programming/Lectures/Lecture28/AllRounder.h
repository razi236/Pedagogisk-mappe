#pragma once
#include "Batter.h"
#include "Bowler.h"
class AllRounder:public Bowler, public Batter
{
public:
	AllRounder();
	~AllRounder();
};

