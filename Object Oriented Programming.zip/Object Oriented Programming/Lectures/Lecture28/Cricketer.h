#pragma once
#include <iostream>
using namespace std;

class Cricketer
{
protected:
	int number;
public:
	Cricketer();
	~Cricketer();
	void display();
};

