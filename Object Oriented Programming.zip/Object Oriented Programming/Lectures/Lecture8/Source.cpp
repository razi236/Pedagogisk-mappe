#include "Fraction.h"

int main()
{
	Fraction one(1, 2);
	Fraction two(3, 5);

	Fraction three = one.operator+(two); //one+two

	three.display();
	return 0;
}