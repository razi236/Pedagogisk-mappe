#include "Fraction.h"

Fraction Fraction::operator+(Fraction obj)
{
	Fraction result;

	result.den = den * obj.den;
	result.num = obj.den * num + den * obj.num;

	return result;
}

void Fraction::display()
{
	cout << num << "/" << den << endl;
}

Fraction::Fraction(int n, int d)
{
	num = n;
	if (d==0)
		den = 1;

	den = d;
}

Fraction::Fraction()
{
	num = 0;
	den = 1;
}

