#include <iostream>
#include "Student.h"
using namespace std;


int main()
{
	Student s;

	s.toBreathe();
	s.age = 29;


	return 0;
}