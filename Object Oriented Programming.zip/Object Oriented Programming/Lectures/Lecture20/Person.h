#pragma once
#include <iostream>
using namespace std;
class Person
{
	int age;
	char firstNameInitial;
	char gender;
public:
	void toBreathe();
	void toEat(int food);
	void toSleep();
	Person();
	Person(int);
	~Person();
};

