#include "Person.h"

void Person::toBreathe()
{
	cout << "I am breathing" << endl;
}

void Person::toEat(int food)
{
	cout << "I am eating food" << endl;
}

void Person::toSleep()
{
	cout << "Am I sleeping?" << endl;
}

Person::Person()
{
	cout << "Person()" << endl;
}

Person::Person(int a)
{
	cout << "Person(int)" << endl;
}

Person::~Person()
{
	cout << "~Person()" << endl;
}
