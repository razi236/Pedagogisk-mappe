#include "Student.h"

void Student::toEnjoy()
{
	cout << "toEnjoy()" << endl;
}

Student::Student()
{
	cout << "Student()" << endl;
}


Student::~Student()
{
	cout << "~Student()" << endl;
}
