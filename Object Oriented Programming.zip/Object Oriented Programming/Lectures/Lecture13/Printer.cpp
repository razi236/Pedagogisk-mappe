#include "Printer.h"

void Printer::setCount(int c)
{
	count = c;
}

int Printer::getCount()
{
	return count;
}

Printer& Printer::operator = (const Printer& rhs)
{
	if (this != &rhs)
	{
		*instance = *rhs.instance;
	}

	return *this;
}

Printer::Printer(const Printer& rhs)
{
	instance = new int;
	*instance = *rhs.instance;
}

void Printer::display() const
{
	cout << *instance << endl;
}

Printer::Printer(int value)
{
	cout << "Printer(int)" << endl;
	instance = new int;
	*instance = value;
}


Printer::~Printer()
{
	delete instance;
	instance = nullptr;
}
