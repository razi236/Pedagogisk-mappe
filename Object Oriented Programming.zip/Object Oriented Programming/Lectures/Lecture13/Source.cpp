#include <iostream>
#include "Printer.h"
using namespace std;

int Printer::count = 999;

int main()
{


	cout << Printer::getCount() << endl;

	/*
	Printer arr[3];

	Printer xyz;

	xyz.setCount(15); //count = 15

	cout << arr[1].getCount() << endl; //15

	arr[2].setCount(arr[0].getCount() + 1); //count = 16

	cout << xyz.getCount() << endl; //16
	*/
	return 0;
}