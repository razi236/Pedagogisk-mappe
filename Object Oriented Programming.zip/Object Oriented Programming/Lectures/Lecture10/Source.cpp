#include "Fraction.h"

int main()
{

	int a = 5;
	int b = 0;

	b = ++++++a;

	cout << a << endl;
	cout << b << endl;


	/*
	Fraction one(1, 2);

	Fraction two;

	two = -one;

	two.display();

	/*
	Fraction one(6, 10);
	Fraction two(3, 5);
	Fraction three;
	
	if (one == two)
		cout << "Yes" << endl;
	else
		cout << "No" << endl;
		*/
	return 0;
}