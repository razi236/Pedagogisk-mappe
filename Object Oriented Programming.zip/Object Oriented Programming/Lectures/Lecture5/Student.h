#include <iostream>
using namespace std;

class Student
{
	//attributes (variables):
	int age;
	float CGPA;
	char* name;

	
public:
	//methods (functions) - only prototypes:
	void toStudy(int);
	char earnGrades(float);
	void display();

	//getters (accessor):
	float getCGPA();
	char* getName();
	int getAge();

	//setters (mutators, modifiers):
	void setAge(int);
	void setCGPA(float);
	void setName(char*);

	//Constructor:
	//Functions which are invoked automatically
	//During the object creation (instantiation)
	//For an object, only ONE constructor can be called


	Student();	//non-parameterized constructor

	Student(int);
	Student(char*);
	Student(int, float, char*);

	Student(Student&);//copy constructor Student(const Student&);



};


// Function Over-loading:
//multiple functions having same name can be distinguised from each other using:
//1. number of paramters
//2. data type of paramters
//3. order (arrangement) of parameters
