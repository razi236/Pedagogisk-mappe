#include "City.h"

void City::start()
{
	cout << "City Car has started" << endl;
}


City::City(double _price, char _colour, double _length):Honda(_price, _colour, _length)
{
	cout << "City(double _price, char _colour, double _length)" << endl;
}


City::~City()
{
	cout << "~City()" << endl;
}
