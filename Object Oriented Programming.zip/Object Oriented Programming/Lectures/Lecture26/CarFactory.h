#pragma once
#include "City.h"
#include "Civic.h"
class CarFactory
{
public:
	static Car* newCar(string description);
};

