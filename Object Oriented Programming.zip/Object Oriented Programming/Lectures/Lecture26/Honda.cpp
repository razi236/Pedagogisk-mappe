#include "Honda.h"

void Honda::display()
{
	Car::display();
	cout << "Length = " << length << endl;
}

Honda::Honda(double _price, char _colour, double _length):Car(_price, _colour)
{
	cout << "Honda(double _price, char _colour, double _length)" << endl;
	length = _length;
}


Honda::~Honda()
{
	cout << "~Honda()" << endl;
}
