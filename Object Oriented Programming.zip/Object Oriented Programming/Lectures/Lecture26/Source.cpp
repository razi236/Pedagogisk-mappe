#include "CarFactory.h"

int main()
{
	string desc = "City";

	Car* car = CarFactory::newCar(desc);
	car->start();

	desc = "Civic";
	car = CarFactory::newCar(desc);
	car->start();

	return 0;
}