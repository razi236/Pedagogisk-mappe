#pragma once
#include "Honda.h"
class City:public Honda
{
public:
	City(double _price, char _colour, double _length);
	~City();
	void start();
};

