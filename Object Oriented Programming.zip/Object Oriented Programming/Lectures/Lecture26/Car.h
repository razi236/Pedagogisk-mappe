#pragma once
#include <iostream>
using namespace std;

class Car
{
protected:
	double price;
	char colour;
public:
	virtual void display() = 0;
	Car(double _price, char _colour);
	virtual void start() = 0;
	virtual ~Car();
};

