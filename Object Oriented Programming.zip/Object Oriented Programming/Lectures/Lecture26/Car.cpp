#include "Car.h"

void Car::display()
{
	cout << "Price = " << price << endl;
	cout << "Colour = " << colour << endl;
}


Car::Car(double _price, char _colour)
{
	cout << "Car(double _price, char _colour);" << endl;
	price = _price;
	colour = _colour;
}


Car::~Car()
{
	cout << "~Car()" << endl;
}
