#pragma once
#include "Honda.h"
class Civic:public Honda
{
	double width;
	bool sunroof;
public:
	Civic(double _price, char _colour, double _length, double _width, bool _sunroof);
	void display();
	void start();
	~Civic();
};

