#include "CarFactory.h"



Car* CarFactory::newCar(string description)
{
	if (description == "City")
		return new City(3.9, 'r', 5.2);

	else if (description == "Civic")
		return new Civic(6.3, 's', 5.2, 6.3, true);
}
