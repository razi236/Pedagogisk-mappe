#include "Fraction.h"

Fraction Fraction::operator++(int)
{
	Fraction returnValue = *this;

	num = num + den;

	return returnValue;
}

Fraction& Fraction::operator++()
{
	num = num + den;
	return*this;
}

Fraction Fraction::operator-()
{
	Fraction res;

	res.num = -1 * num;
	res.den = den;

	return res;
}


Fraction Fraction::operator+()
{
	return *this;
}

bool Fraction::operator==(const Fraction& obj)
{
	return (num == obj.num && den == obj.den);
}


Fraction Fraction::operator-(const Fraction& obj)
{
	Fraction result;

	result.den = den * obj.den;
	result.num = obj.den * num - den * obj.num;

	return result;
}

Fraction& Fraction::operator=(const Fraction& obj)
{
	//cout << "operator = " << endl;

	num = obj.num;
	den = obj.den;

	return *this;
	
}

Fraction::Fraction(const Fraction& obj)
{
	//cout << "Copy Constructor" << endl;
	num = obj.num;
	den = obj.den;
}

Fraction Fraction::operator+(const Fraction &obj)
{
	Fraction result;

	result.den = den * obj.den;
	result.num = obj.den * num + den * obj.num;

	return result;
}

void Fraction::display()
{
	cout << num << "/" << den << endl;
}

Fraction::Fraction(int n, int d)
{
	//cout << "Constructor(int, int)" << endl;
	num = n;
	if (d==0)
		den = 1;

	den = d;
}

Fraction::Fraction()
{
	//cout << "Constructor()" << endl;
	num = 0;
	den = 1;
}

