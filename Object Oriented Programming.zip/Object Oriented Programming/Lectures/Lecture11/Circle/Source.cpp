#include "Circle.h"

int main()
{
	Circle c1;

	Circle c2(4.8);

	c1.display();
	c2.display();

	//c1 = c2;

	return 0;
}