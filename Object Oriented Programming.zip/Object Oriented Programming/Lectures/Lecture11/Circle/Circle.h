#include <iostream>
using namespace std;

class Circle
{
	//int temp;
	double* radius;
	const double pi;
public:
	double area() const;
	double circumference() const;
	double diameter() const;
	void display() const;
	Circle(double r = 0);
	Circle(const Circle&);
	~Circle();
};

