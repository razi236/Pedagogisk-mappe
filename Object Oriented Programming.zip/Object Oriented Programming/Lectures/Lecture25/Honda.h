#pragma once
#include "Car.h"
class Honda:public Car
{
protected:
	double length;
public:
	//Inherited ------> virtual void display() = 0;
	// therefore over-ride it:
	void display();
	Honda(double _price, char _colour, double _length);
	~Honda();
};

