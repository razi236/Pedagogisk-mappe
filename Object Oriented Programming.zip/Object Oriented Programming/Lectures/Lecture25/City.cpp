#include "City.h"


City::City(double _price, char _colour, double _length):Honda(_price, _colour, _length)
{
}


City::~City()
{
	cout << "~City()" << endl;
}
