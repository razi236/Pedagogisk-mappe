#include "Civic.h"

void Civic::display()
{
	cout << "Width = " << width << endl;
	cout << "Sunroof = " << sunroof << endl;
}


Civic::Civic(double _price, char _colour, double _length, double _width, bool _sunroof) :Honda(_price, _colour, _length)
{
	cout << "Civic(double _price, char _colour, double _length, double _width, bool _sunroof) :Honda(_price, _colour, _length)" << endl;
	width = _width; 
	sunroof = _sunroof;
}


Civic::~Civic()
{
	cout << "~Civic()" << endl;
}
