#pragma once
#include <iostream>
using namespace std;

class TaskManager
{
	int* ram;
	static int count;
	static TaskManager* object;
	TaskManager(int);
	~TaskManager();
public:
	static TaskManager* CreateObject();
	void display() const;

	static void DeleteObject(TaskManager*&);
};

