#include "TaskManager.h"

int TaskManager::count = 0;
TaskManager* TaskManager::object = nullptr;

int main()
{
	TaskManager* t1 = TaskManager::CreateObject();
	TaskManager* t2 = TaskManager::CreateObject();
	TaskManager* t3 = TaskManager::CreateObject();

	TaskManager::DeleteObject(t2);
	TaskManager::DeleteObject(t1);
	TaskManager::DeleteObject(t3);

	return 0;
}