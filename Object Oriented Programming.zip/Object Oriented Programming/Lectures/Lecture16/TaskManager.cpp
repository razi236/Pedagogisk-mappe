#include "TaskManager.h"

void TaskManager::DeleteObject(TaskManager*& ptr)
{
	if (count == 1)
	{
		ptr = nullptr;
		delete object;
		object = nullptr;
		count--;
	}

	if (count > 1)
	{
		ptr = nullptr;
		count--;
	}
}


TaskManager* TaskManager::CreateObject()
{
	if (count == 0 && object == nullptr)
		object = new TaskManager(8);

	count++;

	return object;
}

void TaskManager::display() const
{
	cout << "The RAM is: " << *ram << endl;
	cout << "Count = " << count << endl;
}

TaskManager::TaskManager(int r)
{
	ram = new int;
	*ram = r;

	cout << "TaskManager(int)" << endl;
}


TaskManager::~TaskManager()
{
	delete ram;
	ram = nullptr;
	cout << "~TaskManager()" << endl;
}
