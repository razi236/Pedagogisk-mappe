#pragma once
#include <iostream>
using namespace std;

class Shape
{
protected:
	double width;
	double length;
	double height;	
public:
	virtual double area();
	double volume();
	Shape();
	Shape(double, double, double);
	virtual ~Shape();
	void display();
};

