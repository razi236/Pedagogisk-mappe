#include "Square.h"

Square::Square(double side) :Rectangle(side, side)
{
	cout << "Square(double)" << endl;
	
}


Square::Square()
{
	cout << "Square()" << endl;
	display();
}


Square::~Square()
{
	cout << "~Square()" << endl;
}
