#pragma once
#include "Rectangle.h"
class Square :public Rectangle
{
public:
	Square();
	Square(double);
	~Square();
};

