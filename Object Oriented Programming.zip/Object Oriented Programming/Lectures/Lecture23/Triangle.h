#pragma once
#include "Shape.h"
class Triangle:public Shape
{
public:
	Triangle();
	Triangle(double, double);
	~Triangle();

	double area(); //over-ridden function

	//void d();	//wraPPER

	//double a();	//WRA	PPER
};

