#include "Rectangle.h"


Rectangle::Rectangle()
{
	cout << "Rectangle()" << endl;
	width = 13;
}

Rectangle::Rectangle(double l, double w) :Shape(l,w,0)
{
	cout << "Rectangle(double, double)" << endl;
	//length = 10;
	
}


Rectangle::~Rectangle()
{
	cout << "~Rectangle()" << endl;
}
