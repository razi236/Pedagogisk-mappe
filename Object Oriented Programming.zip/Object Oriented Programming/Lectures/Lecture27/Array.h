#pragma once
#include <iostream>
using namespace std;

template <class T>
class Array
{
	T* arr;
	int maxSize;
	int currentSize;
public:
	Array(int s);
	void addValue(T value);
	T remValue();
	~Array();

	void display();
};

template <class KuchAur>
void Array<KuchAur>::display()
{
	cout << "MaxSize =" << maxSize << endl;
	cout << "CurrentSize = " << currentSize << endl;

	for (int i = 0; i < currentSize; i++)
	{
		cout << i << ". " << arr[i] << endl;
	}
}

template <class T>
Array<T>::Array(int s)
{
	arr = new T[s];
	maxSize = s;
	currentSize = 0;
}


template <class KuchAur>
void Array<KuchAur>::addValue(KuchAur value)
{
	arr[currentSize++] = value;
}

template <class Gen>
Gen Array<Gen>::remValue()
{
	return arr[--currentSize];
}

template <class T>
Array<T>::~Array()
{
	delete[]arr;
}


