#include "Array.h"
#include "Fraction.h"

int main()
{
	Array<Fraction> f(15);
	Fraction one(1, 2);
	Fraction two(3, 5);

	f.addValue(one);
	f.addValue(two);

	cout << f.remValue() << endl;

	f.display();


	cout << endl << endl;

	Array<int> obj(85);
	obj.addValue(10);
	obj.addValue(-3);
	obj.addValue(15);
	obj.display();


	cout << endl << endl;
	Array<char> abc(10);
	abc.addValue('A');
	abc.addValue('z');
	cout << abc.remValue() << endl;
	abc.display();
	


	return 0;
}