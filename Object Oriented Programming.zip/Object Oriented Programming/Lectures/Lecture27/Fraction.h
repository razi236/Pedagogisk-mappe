#pragma once
#include <iostream>
using namespace std;

class Fraction
{
	int num;
	int den;
public:
	Fraction();
	Fraction(int, int);

	Fraction(const Fraction& obj);

	bool operator==(const Fraction&obj);

	Fraction operator+(const Fraction &obj);
	Fraction operator-(const Fraction& obj);

	Fraction& operator=(const Fraction& obj);

	Fraction operator+(); //unary operator
	Fraction operator-(); //unary operator

	Fraction& operator++();	//pre and & is for ++++++a
	Fraction operator++(int); //post and int is for post

	friend ostream& operator<<(ostream& out, const Fraction &f)
	{
		out << f.num << "/" << f.den;
		return out;
	}

	friend istream& operator>>(istream& is, Fraction & f)
	{
		cout << "Input Num: ";
		is >> f.num; 
		cout << "Input Den: ";
		is >> f.den;
		return is;
	}


};

