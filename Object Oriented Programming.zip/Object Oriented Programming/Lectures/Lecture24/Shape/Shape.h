#pragma once
#include <iostream>
using namespace std;

class Shape
{
protected:
	double width;
	double length;
	double height;	
public:
	virtual double area() = 0; //pure virtual function - a pure virtual function makes your class ABSTRACT
	double volume();
	Shape();
	Shape(double, double, double);
	virtual ~Shape();
	void display();
};

