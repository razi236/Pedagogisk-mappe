#include <iostream>
#include "Rectangle.h"
#include "Triangle.h"
#include "Square.h" 
using namespace std;

int main()
{
	//There is a case where a parent class can point to the child classes

	Shape *ptr[3];

	/*cout << endl << endl;
	Shape s;
	s.display();
	cout << s.area() << endl;
	cout << s.volume() << endl;
	cout << endl << endl;
	*/

	
	ptr[0] = new Rectangle(5, 6);
	ptr[1] = new Triangle(3.3, 8.9);
	ptr[2] = new Square(4);


	for (int i = 0; i < 3; i++)
		cout << ptr[i]->area() << endl;
	

	for (int i = 0; i < 3; i++)
		delete ptr[i];







	/*
	Shape *ptr;



	ptr = new Rectangle(5, 6);
	ptr->display();
	delete ptr;



	ptr = nullptr;

	ptr = new Triangle(3.3, 8.9);
	ptr->display();


Rectangle r(6,5);
	Triangle t(3.3, 8.9);

	ptr[0] = &r;
	ptr[0]->display();
	r.display();

	ptr[1] = &t;
	ptr[1]->display();
	t.display();
	*/
	return 0;
}