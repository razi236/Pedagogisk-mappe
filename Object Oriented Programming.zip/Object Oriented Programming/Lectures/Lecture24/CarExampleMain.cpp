#include <iostream>
using namespace std;

int main()
{
	Car* ptr[3];	// Car is an abstract class
	ptr[0] = new Honda(6.3, 'b'); //price, colour
	ptr[1] = new City(3.9, 'r', 5.2); //price, colour, length
	ptr[2] = new Civic(6.3, 's', 5.2, 6.3, true); //price, colour, length, width, sunroof


	for (int i = 0; i < 3; i++)
		ptr[i]->display();
	
	for (int i = 0; i < 3; i++)
		delete ptr[i];
	

	return 0;
}