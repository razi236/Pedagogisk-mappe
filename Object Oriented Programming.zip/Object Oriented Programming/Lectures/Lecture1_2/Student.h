#include <iostream>
using namespace std;


class Student
{
private:
	//attributes (variables):
	int age;
	float CGPA;
	char* name;

public:
	//methods (functions) - only prototypes:
	void toStudy(int);
	char earnGrades(float);


};