#include"Student.h"

int main()
{
	Student one, two;		//Student one;
							//Student two;

	one.toStudy(100);


	//one.CGPA = 4.2;

	//two.CGPA = 3.33;

	//cout << one.CGPA << endl;
	//cout << two.CGPA << endl;

	return 0;
}