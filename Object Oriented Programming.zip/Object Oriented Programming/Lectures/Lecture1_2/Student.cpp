#include "Student.h"


void Student::toStudy(int money)
{
	cout << "To make money halal" << endl;
	cout << money << endl;
}

char Student::earnGrades(float marks)
{
	if (marks >= 86)
		return'A';

	else if (marks < 50)
		return'F';

	else
		return 'C';
}