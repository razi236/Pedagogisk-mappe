#include "Student.h"

Student::~Student()
{
	cout << "~Student()" << endl;

	if (name != nullptr)
	{
		delete[] name;
		name = nullptr;
	}
}

Student::Student(const Student &other)
{
	cout << "Copy Constructor" << endl;
	age = other.age;
	CGPA = other.CGPA;

	//name = other.name;

	int len = strlen(other.name);

	name = new char[len + 1];

	name[len] = '\0';

	for (int i = 0; i < len; i++)
	{
		name[i] = other.name[i];
	}
}

Student::Student(int a, float cgpa, char* n)
{
	cout << "Student(int, float, char*)" << endl;
	age = a;
	CGPA = cgpa;

	int len = strlen(n);

	name = new char[len + 1];

	name[len] = '\0';

	for (int i = 0; i < len; i++)
	{
		name[i] = n[i];
	}
}

Student::Student(char* n)
{
	cout << "Student(char*)" << endl;
	
	int len = strlen(n);

	name = new char[len + 1];

	name[len] = '\0';

	for (int i = 0; i < len; i++)
	{
		name[i] = n[i];
	}

	//age = 0;
	//CGPA = 0;
}

Student::Student(int a)
{
	cout << "Student(int)" << endl;
	age = a;
}

Student::Student()
{
	cout << "Non-parameterized Constructor" << endl;
	age = 10;
	CGPA = 0.01;
	name = nullptr;
}

void Student::display()
{
	cout << "Age = " << age << endl;
	cout << "CGPA = " << CGPA << endl;
	if (name!=nullptr)
		cout << "Name = " << name << endl;
	else
		cout << "Name = nullptr" << endl;
}

void Student::setAge(int a)
{
	age = a;
}

void Student::setCGPA(float cgpa)
{
	CGPA = cgpa;
}

//getter of name - this is RIGHT:
char* Student::getName()
{
	//return name; this is wrong

	int length = 0;

	while (1)
	{
		if (name[length] == '\0')
			break;

		length++;
	}

	char* abc = new char[length + 1];;

	for (int i = 0; i < length; i++)
	{
		abc[i] = name[i];
	}

	abc[length] = '\0';

	return abc;
}

//setter of name - this is CORRECT
void Student::setName(char* n)
{

	if (name != nullptr)
	{
		delete[] name;
		name = nullptr;
	}

	//name = n;  this is WRONG:
	int length = 0;

	while (1)
	{
		if (n[length] == '\0')
			break;

		length++;
	}

	name = new char[length + 1];

	for (int i = 0; i < length; i++)
	{
		name[i] = n[i];
	}

	name[length] = '\0';
}

float Student::getCGPA()
{
	return CGPA;
}



int Student::getAge()
{
	return age;
}

void Student::toStudy(int money)
{
	cout << "To make money halal" << endl;
	cout << money << endl;
}

char Student::earnGrades(float marks)
{
	if (marks >= 86)
	{
		CGPA = 4.00;
		return'A';
	}

	else if (marks < 50)
	{
		CGPA = 0;
		return'F';
	}

	else
	{
		CGPA = 2.33;
		return 'C';
	}
		
}