#include"Student.h"

int main()
{
	char temp[4] = { 'A', 'l', 'i', '\0' };

	Student obj (20, 3.5, temp);

	char temp2[5] = { 'O','m', 'e', 'r', '\0' };

	obj.setName(temp2);





	//Student one(18, 0.01, temp);

	//{
	//	Student one;
	//}


	//Student two(one);

	//cout << "Object Two: " << endl;


	/*Student obj;

	char temp[4] = { 'A', 'l', 'i', '\0' };

	cout << temp << endl;

	obj.setName(temp);

	cout << obj.getName() << endl;

	temp[0] = 'X';

	cout << obj.getName() << endl;*/

	/*	Student one;	//non- para constructor

	Student two(5);	//parameterized constuctor called

	char temp[4] = { 'A', 'l', 'i', '\0' };
	Student three(temp); //parameterized constuctor called

	three.display();
	/*/

	return 0;
}